from operate.RequestOperate import HttpSession

s = HttpSession()