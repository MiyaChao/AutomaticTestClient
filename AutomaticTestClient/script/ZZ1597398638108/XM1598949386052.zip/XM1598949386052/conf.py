from method.PublicMethod import *

adminUser=('admin@pvc123.com',
'sdc5r9y9owfndtijuhtM52YRDmbIKKGHkEsQ2Lh4HHoJrq0nYtl+nhC8NZ89hVZQvyjw6P/W2Y2EKOR3yST8p5xfSnfU1j59PVNSoGUQfk2AGN+F6k/lO5Ke3Fs4gbjsKkndxCT9xlPPLCdpedP8uVwfyxXjUYbWIPIzhPDXqvY='
           )

host='http://flow.dasu123.inet'
# host=publicMethod.getEnvironmentVariable("host")


terminal='flow'
# terminal='wxAudit'